import React, { useState } from "react";
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet, Button } from "react-native";

const jobData = [
  { id: "1", title: "Software Engineer", description: "Develop web and mobile apps." },
  { id: "2", title: "UI/UX Designer", description: "Create stunning user interfaces." },
  { id: "3", title: "Data Scientist", description: "Analyze data for insights." },
];

export default function App() {
  const [username, setUsername] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);

  // Login Screen
  if (!loggedIn) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Login</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your name"
          value={username}
          onChangeText={setUsername}
        />
        <Button title="Login" onPress={() => username ? setLoggedIn(true) : alert("Enter a name")} />
      </View>
    );
  }

  // Job Listings or Job Details
  return (
    <View style={styles.container}>
      {selectedJob ? (
        <View>
          <Text style={styles.jobTitle}>{selectedJob.title}</Text>
          <Text style={styles.jobDesc}>{selectedJob.description}</Text>
          <TouchableOpacity onPress={() => setSelectedJob(null)}>
            <Text style={styles.backButton}>← Back to Jobs</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={jobData}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.jobItem} onPress={() => setSelectedJob(item)}>
              <Text style={styles.jobTitle}>{item.title}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f4f4f4", justifyContent: "center" },
  title: { fontSize: 24, fontWeight: "bold", textAlign: "center", marginBottom: 20 },
  input: { borderWidth: 1, padding: 10, marginBottom: 20, borderRadius: 8, backgroundColor: "white" },
  jobItem: { padding: 15, backgroundColor: "white", marginBottom: 10, borderRadius: 8 },
  jobTitle: { fontSize: 18, fontWeight: "bold" },
  jobDesc: { fontSize: 16, marginTop: 10 },
  backButton: { color: "blue", marginTop: 10, fontSize: 16 },
});
